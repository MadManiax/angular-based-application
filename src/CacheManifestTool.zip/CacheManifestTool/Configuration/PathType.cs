﻿namespace CacheManifestTool.Configuration
{
    public enum PathType
    {
        Folder,
        File,
        Wildcard
    }
}